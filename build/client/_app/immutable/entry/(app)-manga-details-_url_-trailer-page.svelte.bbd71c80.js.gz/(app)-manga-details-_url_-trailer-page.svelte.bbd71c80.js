import{S as e,i as t,s as a}from"../chunks/index.28a8b093.js";class o extends e{constructor(s){super(),t(this,s,null,null,a,{})}}export{o as default};
