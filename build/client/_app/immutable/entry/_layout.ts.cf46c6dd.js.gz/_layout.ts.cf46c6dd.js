import{l as t}from"../chunks/_layout.80a33c1a.js";import"../chunks/UserSettingStore.4034ccb9.js";import"../chunks/queryClient.2c5393f3.js";export{t as load};
