import"../chunks/useMediaDetailsPrefetch.416c9d19.js";import"../chunks/hydration.ab7dd347.js";import{l as t}from"../chunks/_layout.d679bdc3.js";export{t as load};
