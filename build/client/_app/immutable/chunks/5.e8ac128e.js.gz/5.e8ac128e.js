import{default as t}from"../entry/(app)-manga-read-_idChapter_-_urlManga_-layout@.svelte.4a3a7928.js";export{t as component};
