import{default as t}from"../entry/(app)-character-_urlCharacter_-page@(app).svelte.d059c139.js";export{t as component};
