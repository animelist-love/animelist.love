import{w as s}from"./index.c00baded.js";const e=s(!0),o=s(!0),i=s(!1),n=s(!1),a=s(!1);a.set("ontouchstart"in document.documentElement);export{e as a,i as b,o as c,a as d,n as i};
