import{default as t}from"../entry/(app)-staff-_urlStaff_-page@(app).svelte.7b96f84a.js";export{t as component};
