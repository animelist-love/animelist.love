import{c as a,Q as o}from"./index.f1452f32.js";import{k as u}from"./notifyManager.1ad54c9f.js";function Q(r,e,s){const t=u(r,e,s);return a(t,o)}export{Q as c};
