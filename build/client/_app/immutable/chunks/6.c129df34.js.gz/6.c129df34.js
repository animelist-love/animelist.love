import{default as t}from"../entry/(app)-page.svelte.ebd8d4fe.js";export{t as component};
