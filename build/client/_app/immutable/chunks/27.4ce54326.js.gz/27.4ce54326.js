import{default as t}from"../entry/(app)-timeline-page@(app).svelte.8998adcd.js";export{t as component};
