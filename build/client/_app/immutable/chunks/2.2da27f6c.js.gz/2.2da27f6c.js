import{default as t}from"../entry/(app)-layout.svelte.f0d65bbf.js";export{t as component};
