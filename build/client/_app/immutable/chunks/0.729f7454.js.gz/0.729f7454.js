import{_ as r}from"./_layout.80a33c1a.js";import{default as t}from"../entry/_layout.svelte.8be569ce.js";export{t as component,r as universal};
