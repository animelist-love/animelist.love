import{default as t}from"../entry/(app)-studio-_urlStudio_-page@(app).svelte.36745d4e.js";export{t as component};
