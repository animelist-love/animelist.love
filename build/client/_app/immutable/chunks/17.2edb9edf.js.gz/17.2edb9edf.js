import{default as t}from"../entry/(app)-manga-page@(app).svelte.856a8a08.js";export{t as component};
