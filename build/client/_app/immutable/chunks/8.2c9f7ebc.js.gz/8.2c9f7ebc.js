import{default as t}from"../entry/(app)-anime-details-_url_-characters-page.svelte.1de05dca.js";export{t as component};
