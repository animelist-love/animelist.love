import{default as t}from"../entry/(app)-anime-details-_url_-relations-page.svelte.160b2997.js";export{t as component};
