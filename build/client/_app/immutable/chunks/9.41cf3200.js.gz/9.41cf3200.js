import{default as t}from"../entry/(app)-anime-details-_url_-recommendations-page.svelte.3ccd5488.js";export{t as component};
