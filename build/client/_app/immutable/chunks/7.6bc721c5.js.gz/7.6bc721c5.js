import{default as t}from"../entry/(app)-anime-details-_url_-page.svelte.a3ce6a7e.js";export{t as component};
