import{default as t}from"../entry/error.svelte.cd784ab0.js";export{t as component};
