import{_ as r}from"./_layout.b4824eec.js";import{default as t}from"../entry/(app)-anime-details-_url_-layout@(app).svelte.81d8fd8f.js";export{t as component,r as universal};
