import{default as t}from"../entry/(app)-browse-page@(app).svelte.5eb0b78a.js";export{t as component};
