import{b as s}from"./index.63504a90.js";const t=e=>parseInt(e==null?void 0:e.slice((e==null?void 0:e.lastIndexOf("an"))+2)),i=e=>s(e);export{i as a,t as u};
