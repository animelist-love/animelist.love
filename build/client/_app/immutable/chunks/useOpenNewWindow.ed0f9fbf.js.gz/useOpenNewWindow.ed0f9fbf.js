const e=n=>{n&&window.open(n,"_blank")};export{e as u};
