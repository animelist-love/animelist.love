import{default as t}from"../entry/(app)-manga-read-_idChapter_-_urlManga_-page.svelte.3a47189c.js";export{t as component};
