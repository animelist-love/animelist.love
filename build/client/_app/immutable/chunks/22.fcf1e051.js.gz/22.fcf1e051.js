import{default as t}from"../entry/(app)-manga-details-_url_-staff-page.svelte.d5c733a9.js";export{t as component};
