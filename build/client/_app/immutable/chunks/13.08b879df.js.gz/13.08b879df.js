import{default as t}from"../entry/(app)-anime-view-_idEpisode_-_urlAnime_-page.svelte.8eb726fd.js";export{t as component};
